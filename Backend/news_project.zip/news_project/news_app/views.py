import requests
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET'])
def get_news(request):
    """
    Fetch news articles related to 'Apple' from NewsAPI.org.
    """
    NEWS_API_KEY = "9cf87a63-a525-4f3c-aa81-be6752bae29d"
    url = f"https://eventregistry.org/api/v1/article/getArticles?apiKey={NEWS_API_KEY}"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            error_data = {
                "error": f"Received status code {response.status_code}",
                "details": response.json()
            }
            print(error_data)  # Print error details to console
            return Response(error_data, status=response.status_code)
        
        data = response.json() # Print the JSON data to the console
        return Response(data)
        
    except Exception as e:
        error_data = {"error": str(e)}
        print(error_data)  # Print exception error details to console
        return Response(error_data, status=500)
